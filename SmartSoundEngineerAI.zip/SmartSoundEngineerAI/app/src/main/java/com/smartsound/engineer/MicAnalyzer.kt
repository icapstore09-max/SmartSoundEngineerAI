package com.smartsound.engineer

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.*

/**
 * EXPERIMENTAL. Listens to the phone MICROPHONE (the room), not to mixer channels:
 * the Ui12 does not stream channel audio over Wi-Fi. Heuristic rules, not a trained model,
 * not validated. It cannot tell which mixer channel an instrument is on.
 */
object MicAnalyzer {
    private const val SR = 16000
    private const val N = 2048

    @SuppressLint("MissingPermission")
    fun listen(seconds: Int, done: (String) -> Unit) {
        Thread {
            val min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(min, N * 4))
            if (rec.state != AudioRecord.STATE_INITIALIZED) { done("Microphone could not start."); return@Thread }
            val buf = ShortArray(N)
            val rms = ArrayList<Double>(); val cent = ArrayList<Double>(); val flat = ArrayList<Double>()
            var low = 0.0; var mid = 0.0; var high = 0.0
            rec.startRecording()
            val frames = seconds * SR / N
            var got = 0
            while (got < frames) {
                var off = 0
                while (off < N) { val r = rec.read(buf, off, N - off); if (r <= 0) break; off += r }
                if (off < N) break
                got++
                val x = DoubleArray(N) { buf[it] / 32768.0 * (0.5 - 0.5 * cos(2 * PI * it / N)) }
                rms.add(sqrt(x.sumOf { it * it } / N))
                val re = x.copyOf(); val im = DoubleArray(N)
                fft(re, im)
                val mag = DoubleArray(N / 2) { hypot(re[it], im[it]) + 1e-12 }
                val hz = SR.toDouble() / N
                var s = 0.0; var w = 0.0; var lg = 0.0
                for (k in 2 until N / 2) {
                    val f = k * hz; s += mag[k]; w += mag[k] * f; lg += ln(mag[k])
                    val e = mag[k] * mag[k]
                    if (f < 300) low += e else if (f < 3000) mid += e else high += e
                }
                cent.add(w / s)
                flat.add(exp(lg / (N / 2 - 2)) / (s / (N / 2 - 2)))
            }
            rec.stop(); rec.release()
            if (rms.size < 5) { done("Not enough audio captured."); return@Thread }
            val avgRms = rms.average()
            if (avgRms < 0.003) { done("Too quiet to analyze (room level very low)."); return@Thread }
            val dur = rms.size * N.toDouble() / SR
            var onsets = 0
            for (i in 1 until rms.size) if (rms[i] > rms[i - 1] * 1.8 && rms[i] > avgRms * 1.2) onsets++
            val onsetRate = onsets / dur
            val tot = low + mid + high
            val lowR = low / tot; val midR = mid / tot; val highR = high / tot
            val c = cent.average(); val fl = flat.average()
            val steady = rms.map { abs(it - avgRms) / avgRms }.average()
            val tonal = fl < 0.12
            val sc = linkedMapOf(
                "darbuka / percussion" to (if (onsetRate >= 2.5) 2.0 else 0.0) + (if (!tonal) 1.0 else 0.0) + (if (lowR > 0.3) 0.7 else 0.0),
                "vocals" to (if (midR > 0.55) 1.0 else 0.0) + (if (c in 500.0..2200.0) 1.0 else 0.0) + (if (tonal) 0.7 else 0.0) + (if (onsetRate < 2.5) 0.5 else 0.0),
                "oud" to (if (tonal) 1.0 else 0.0) + (if (c < 1200) 1.0 else 0.0) + (if (onsetRate in 0.8..4.0) 1.0 else 0.0) + (if (lowR > 0.25) 0.5 else 0.0),
                "guitar" to (if (tonal) 1.0 else 0.0) + (if (c in 900.0..3000.0) 1.0 else 0.0) + (if (onsetRate in 0.8..4.0) 1.0 else 0.0),
                "keyboard" to (if (tonal) 1.0 else 0.0) + (if (steady < 0.35) 1.0 else 0.0) + (if (onsetRate < 1.5) 1.0 else 0.0)
            )
            val top = sc.entries.sortedByDescending { it.value }.take(2)
            done("Room-mic guess (LOW confidence, heuristic): ${top[0].key}, maybe ${top[1].key}.\n" +
                "centroid=${c.roundToInt()}Hz onsets/s=${"%.1f".format(onsetRate)} tonal=${"%.2f".format(fl)} " +
                "low/mid/high=${(lowR * 100).roundToInt()}/${(midR * 100).roundToInt()}/${(highR * 100).roundToInt()}%\n" +
                "This hears the whole room, not individual channels. Mixed instruments confuse it.")
        }.start()
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t; val u = im[i]; im[i] = im[j]; im[j] = u }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val tr = re[b] * cr - im[b] * ci; val ti = re[b] * ci + im[b] * cr
                    re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti
                    val nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
