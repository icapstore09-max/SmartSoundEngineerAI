package com.smartsound.engineer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.core.app.NotificationCompat
import java.util.Locale

object Engine : MixerClient.Listener {
    const val CH_ALERT = "alerts"
    const val CH_MON = "monitor"
    const val NCH = 12  // Ui12 input channels
    // UNVERIFIED guess of VU2 layout. Adjust after looking at the raw VU info in the app.
    @Volatile var vuHeader = 4
    @Volatile var vuStride = 3
    @Volatile var vuOffsetInStride = 1

    private lateinit var ctx: Context
    private var tts: TextToSpeech? = null
    @Volatile var speak = false
    val channels = Array(NCH) { Channel(it) }
    val alerts = ArrayList<Alert>()
    val rawLog = ArrayDeque<String>()
    @Volatile var status = "Not connected"
    @Volatile var setdCount = 0
    @Volatile var vuInfo = "No VU frames received yet"
    val client = MixerClient(this)
    private var inited = false

    fun init(c: Context) {
        if (inited) return
        inited = true
        ctx = c.applicationContext
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Mixer alerts", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel(CH_MON, "Monitoring", NotificationManager.IMPORTANCE_LOW))
        }
        tts = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    }

    fun log(s: String) = synchronized(rawLog) { rawLog.addLast(s); while (rawLog.size > 60) rawLog.removeFirst() }

    override fun onStatus(s: String) { status = s; log("[status] $s") }
    override fun onRaw(line: String) = log(line)

    override fun onSetD(path: String, v: Double) {
        setdCount++
        val p = path.split(".")
        if (p.size < 3) return
        val n = p[1].toIntOrNull() ?: return
        if (n !in 0 until NCH) return
        val c = channels[n]
        when {
            p[0] == "i" && p[2] == "mix" -> c.fader = v
            p[0] == "i" && p[2] == "mute" -> c.mute = v >= 0.5
            p[0] == "hw" && p[2] == "gain" -> c.gain = v
            p[0] == "hw" && p[2] == "phantom" -> c.phantom = v >= 0.5
        }
    }

    override fun onSetS(path: String, v: String) {
        val p = path.split(".")
        if (p.size == 3 && p[0] == "i" && p[2] == "name") {
            val n = p[1].toIntOrNull() ?: return
            if (n in 0 until NCH && v.isNotBlank()) channels[n].name = v
        }
    }

    override fun onVu(payload: String) {
        val bytes = try { Base64.decode(payload, Base64.DEFAULT) } catch (e: Exception) { return }
        vuInfo = "VU2 frame: ${bytes.size} bytes (parser layout is an UNVERIFIED guess)"
        val now = System.currentTimeMillis()
        for (i in 0 until NCH) {
            val idx = vuHeader + i * vuStride + vuOffsetInStride
            if (idx >= bytes.size) break
            val c = channels[i]
            c.level = (bytes[idx].toInt() and 0xFF) / 255f
            c.hist.addLast(now to c.level)
            Analyzer.analyze(c, now)?.let { raise(it) }
        }
    }

    private fun raise(a: Alert) {
        synchronized(alerts) { alerts.add(0, a); while (alerts.size > 50) alerts.removeLast() }
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(a.title)
            .setContentText(a.advice)
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.advice))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(1000 + a.channel, n) } catch (_: Exception) {}
        if (speak) tts?.speak(a.title, TextToSpeech.QUEUE_ADD, null, "a${a.time}")
    }
}
