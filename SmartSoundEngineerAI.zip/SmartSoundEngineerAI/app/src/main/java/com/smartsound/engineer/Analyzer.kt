package com.smartsound.engineer

import kotlin.math.sqrt

/** Rule-based detection on meter levels. Thresholds are guesses, NOT tuned on a real mixer. */
object Analyzer {
    private val lastFired = HashMap<String, Long>()
    private const val COOLDOWN = 20_000L

    fun analyze(ch: Channel, now: Long): Alert? {
        val h = ch.hist
        while (h.isNotEmpty() && now - h.first().first > 4000) h.removeFirst()
        if (ch.mute == true) return null
        val name = ch.name

        // Clipping: near full scale for >= 3 consecutive recent frames
        val recent = h.toList().takeLast(3)
        if (recent.size == 3 && recent.all { it.second >= 0.97f } && ready("clip${ch.index}", now)) {
            return Alert(now, ch.index, "CLIP", "Clipping on $name",
                "Lower the input GAIN on this channel (Gain page, not the fader) until peaks sit around -6 dB on the meter. " +
                "If the source is an instrument with a hot output, also try its volume knob or a pad.")
        }

        // Possible feedback: loud, rising or locked steady for ~3s
        if (h.size >= 8 && now - h.first().first >= 2500) {
            val v = h.map { it.second }
            val mean = v.average().toFloat()
            val sd = sqrt(v.map { (it - mean) * (it - mean) }.average()).toFloat()
            val rise = v.takeLast(3).average() - v.take(3).average()
            val rising = v.min() >= 0.5f && rise > 0.15
            val locked = mean >= 0.8f && sd < 0.02f
            if ((rising || locked) && ready("fb${ch.index}", now)) {
                return Alert(now, ch.index, "FEEDBACK?", "Possible feedback on $name",
                    "Quickly pull this channel's fader down a little. If the ringing stops, it was feedback: " +
                    "move the mic away from the speaker/monitor, lower this channel's monitor send, or cut the ringing frequency with a narrow EQ cut. " +
                    "(A steady loud keyboard note can trigger a false alarm.)")
            }
        }
        return null
    }

    private fun ready(key: String, now: Long): Boolean {
        val t = lastFired[key] ?: 0L
        if (now - t < COOLDOWN) return false
        lastFired[key] = now
        return true
    }
}
