package com.smartsound.engineer

class Channel(val index: Int) {
    var name: String = "Ch ${index + 1}"
    var fader: Double? = null     // 0..1 from SETD i.N.mix (UNVERIFIED mapping)
    var mute: Boolean? = null     // SETD i.N.mute
    var gain: Double? = null      // SETD hw.N.gain
    var phantom: Boolean? = null  // SETD hw.N.phantom
    var level: Float = 0f         // 0..1 from VU parse (UNVERIFIED layout)
    val hist = ArrayDeque<Pair<Long, Float>>()
}

data class Alert(val time: Long, val channel: Int, val type: String, val title: String, val advice: String)
