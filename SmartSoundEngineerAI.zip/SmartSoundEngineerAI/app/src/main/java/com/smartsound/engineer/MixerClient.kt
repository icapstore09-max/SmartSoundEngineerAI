package com.smartsound.engineer

import okhttp3.*
import java.util.concurrent.TimeUnit
import java.util.Timer
import kotlin.concurrent.timerTask

/**
 * READ-ONLY client. This class has NO method that sends control commands.
 * The only thing it ever sends is the keep-alive text "3:::ALIVE" (and "2::" heartbeat echo).
 * Protocol knowledge (UNVERIFIED on a real Ui12 by this app): based on fmalcher/soundcraft-ui
 * docs and community reports: plain WebSocket, messages prefixed "3:::", SETD/SETS state lines.
 */
class MixerClient(private val l: Listener) {
    interface Listener {
        fun onStatus(s: String)
        fun onRaw(line: String)
        fun onSetD(path: String, v: Double)
        fun onSetS(path: String, v: String)
        fun onVu(payload: String)
    }

    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    private var ws: WebSocket? = null
    private var timer: Timer? = null
    private var urls = listOf<String>()
    private var urlIdx = 0
    @Volatile private var wantConnected = false

    fun connect(ip: String) {
        disconnect()
        wantConnected = true
        urls = listOf("ws://$ip", "ws://$ip/socket.io/1/websocket/")
        urlIdx = 0
        open()
    }

    fun disconnect() {
        wantConnected = false
        timer?.cancel(); timer = null
        ws?.close(1000, "bye"); ws = null
        l.onStatus("Disconnected")
    }

    private fun open() {
        val url = urls[urlIdx]
        l.onStatus("Connecting to $url ...")
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                l.onStatus("Socket open ($url). Waiting for mixer data... (not yet confirmed as a mixer)")
                timer?.cancel()
                timer = Timer(true).also {
                    it.schedule(timerTask { webSocket.send("3:::ALIVE") }, 0, 1000)
                }
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.startsWith("2::")) { webSocket.send("2::"); return }
                for (line in text.split("\n")) handle(line)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                timer?.cancel()
                l.onStatus("Failed on $url: ${t.message}")
                if (wantConnected) {
                    if (urlIdx + 1 < urls.size) { urlIdx++; open() }
                    else Timer(true).schedule(timerTask { if (wantConnected) { urlIdx = 0; open() } }, 3000)
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                timer?.cancel()
                l.onStatus("Closed ($code)")
            }
        })
    }

    private fun handle(raw: String) {
        if (raw.isBlank()) return
        val m = if (raw.startsWith("3:::")) raw.substring(4) else raw
        val p = m.split("^")
        when (p[0]) {
            "SETD" -> if (p.size >= 3) { p[2].toDoubleOrNull()?.let { l.onSetD(p[1], it) }; l.onRaw(m.take(90)) }
            "SETS" -> if (p.size >= 3) { l.onSetS(p[1], p[2]); l.onRaw(m.take(90)) }
            "VU2" -> if (p.size >= 2) { l.onVu(p[1]) }
            else -> l.onRaw(m.take(90))
        }
    }
}
