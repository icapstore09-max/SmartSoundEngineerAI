package com.smartsound.engineer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var chans: TextView
    private lateinit var alertsTv: TextView
    private lateinit var micTv: TextView
    private lateinit var logTv: TextView

    private fun tv(t: String, size: Float = 14f, mono: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; if (mono) typeface = Typeface.MONOSPACE; setPadding(0, 12, 0, 12)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Engine.init(applicationContext)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(tv("Smart Sound Engineer AI  v0.1 (UNTESTED)", 20f))
        root.addView(tv("READ-ONLY MODE: this version cannot change any mixer setting.", 14f))

        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val ip = EditText(this).apply { hint = "Mixer IP, e.g. 192.168.1.50"; setText(prefs.getString("ip", "")); setSingleLine() }
        root.addView(ip)
        val row = LinearLayout(this)
        val conn = Button(this).apply { text = "Connect" }
        val disc = Button(this).apply { text = "Disconnect" }
        row.addView(conn); row.addView(disc); root.addView(row)
        conn.setOnClickListener {
            val v = ip.text.toString().trim()
            if (v.isEmpty()) { Toast.makeText(this, "Enter the mixer IP", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            prefs.edit().putString("ip", v).apply()
            Engine.client.connect(v)
            ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))
        }
        disc.setOnClickListener { Engine.client.disconnect(); stopService(Intent(this, MonitorService::class.java)) }

        val sw = Switch(this).apply { text = "Spoken alerts"; setOnCheckedChangeListener { _, c -> Engine.speak = c } }
        root.addView(sw)
        status = tv("", 14f); root.addView(status)
        root.addView(tv("Channels (values are UNVERIFIED until you compare with the Ui12 app)", 15f))
        chans = tv("", 12f, true); root.addView(chans)
        root.addView(tv("Alerts", 15f))
        alertsTv = tv("None yet", 13f); root.addView(alertsTv)
        root.addView(tv("Room microphone instrument guess (experimental)", 15f))
        val mic = Button(this).apply { text = "Listen 6 s with phone mic" }
        root.addView(mic)
        micTv = tv("", 13f); root.addView(micTv)
        mic.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            else { micTv.text = "Listening..."; MicAnalyzer.listen(6) { r -> ui.post { micTv.text = r } } }
        }
        root.addView(tv("Raw protocol log (send me this if something looks wrong)", 15f))
        logTv = tv("", 10f, true); root.addView(logTv)
        setContentView(ScrollView(this).apply { addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        tick()
    }

    private fun tick() {
        status.text = "Status: ${Engine.status}\nState messages received: ${Engine.setdCount}\n${Engine.vuInfo}"
        chans.text = Engine.channels.joinToString("\n") { c ->
            "%2d %-10s fd=%s gn=%s %s lvl=%3d%%".format(
                c.index + 1, c.name.take(10),
                c.fader?.let { "%.2f".format(it) } ?: "--",
                c.gain?.let { "%.2f".format(it) } ?: "--",
                if (c.mute == true) "MUTE" else "    ", (c.level * 100).toInt())
        }
        synchronized(Engine.alerts) {
            alertsTv.text = if (Engine.alerts.isEmpty()) "None yet" else
                Engine.alerts.take(6).joinToString("\n\n") { "• ${it.title}\n  ${it.advice}" }
        }
        synchronized(Engine.rawLog) { logTv.text = Engine.rawLog.takeLast(25).joinToString("\n") }
        ui.postDelayed({ tick() }, 500)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 2 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) { micTv.text = "Permission granted. Tap the button again." }
    }
}
