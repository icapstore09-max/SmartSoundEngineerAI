# Smart Sound Engineer AI (v0.1, UNTESTED)
Read-only Ui12 monitor. Build APK via GitHub Actions: see Actions tab -> Build APK -> Artifacts.
